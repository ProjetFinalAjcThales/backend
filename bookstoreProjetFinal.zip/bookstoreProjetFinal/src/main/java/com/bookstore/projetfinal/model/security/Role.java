package com.bookstore.projetfinal.model.security;

public enum Role {
ROLE_USER, ROLE_ADMIN
}
